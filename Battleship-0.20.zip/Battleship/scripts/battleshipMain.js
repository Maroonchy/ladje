// Global Variables
var canvas;
var gl;
var shaderProgram;

// Buffers
var skyboxVertexPositionBuffer = null;
var skyboxVertexTextureCoordBuffer = null;
var seaVertexPositionBuffer = null;
var seaVertexTextureCoordBuffer = null;
var battleshipVertexPositionBuffer = null;
var battleshipIndicesBuffer = null;
var battleshipTextureCoordBuffer = null;
var bsShellVertexPositionBuffer = null;
var bsShellIndicesBuffer = null;
var bsShellTextureCoordBuffer = null;
var enemyShipVertexPositionBuffer = null;
var enemyShipIndicesBuffer = null;
var enemyShipTextureCoordBuffer = null;
var enemyHitboxVertexPositionBuffer = null;
var enemyHitboxVertexTextureCoordBuffer = null;
var worldVertexPositionBuffer = null;
var worldTextureCoordBuffer = null;
var worldIndicesBuffer = null;
var explosionVertexPositionBuffer = null;
var explosionVertexTextureCoordBuffer = null;

// Model-View &+ Matrix stack and Projection Matrices
var mvMatrixStack = [];
var mvMatrix = mat4.create();
var pMatrix = mat4.create();

// Models
var battleship;
var battleshipVertices;
var battleshipIndices;
var battleshipTexCoords;

var enemyShip;
var enemyShipVertices;
var enemyShipIndices;
var enemyShipTexCoords;
var enemyShipenemyHitbox;

var bsShell;
var bsShellVertices;
var bsShellIndices;
var bsShellTexCoords;

var world;
var worldVertices;
var worldIndices;
var worldTexCoords;

// Texture Storage
var seaTexture;
var skyboxTexture;
var battleshipTexture;
var bsShellTexture;
var enemyShipTexture;
var enemyHitboxTexture;
var worldTexture;
var explosionTexture;

// Shells
var bsShellMaxDistance = 200;
var shellSpeed = 0.1;
var shellsFired = [];

// Main Guns
var shootMain = false;
var lastShot = 0;
var nextGun = 1;
var mainDelay = 250;
var mainReload = 1500;
var mainGunDamage = 50;

// Enemy Ships
var spawnedEnemyShips = [];
var enemyShipHealth = 100;
var enemyShipDefaultHitbox;

// Texture Loading State
var texturesLoaded = 0;

// Controls
var currentlyPressedKeys = {};

// Camera
var cameraX = 3;
var cameraY = 2;
var cameraZ = 12;

var cameraHorizontalRate = 0;
var cameraVerticalRate = 0;

var skyboxDistance = 0.5;
var renderDistance = 800;

var battleshipTiltMax = 5;
var battleshipCurrentTiltMax = battleshipTiltMax;
var battleshipTiltStep = 0.005;
var battleshipCurrentTilt = 0;
var battleshipTiltDirection = 0;

// Possition & Speed
var pitch = 0;
var pitchRate = 0;
var yaw = 0;
var yawRate = 0;
var xPosition = 0;
var yPosition = 0.4;
var zPosition = 0;
var speed = 0;
var multiplier = 1;

// Time
var lastTime = 0;


// Utility Functions
function mvPushMatrix()
{
    var copy = mat4.create();
    mat4.set(mvMatrix, copy);
    mvMatrixStack.push(copy);
}


function mvPopMatrix()
{
    if(mvMatrixStack.length == 0)
    {
        throw "Invalid popMatrix!";
    }
    mvMatrix = mvMatrixStack.pop();
}


function degToRad(degrees)
{
    return degrees * Math.PI / 180;
}


function transformScale(array, sizeMultiplier)
{
    for(var i = 0; i < array.length; i++)
    {
        array[i] = array[i] * sizeMultiplier;
    }
}

// Game Functions
function initGL(canvas)
{
    var gl = null;

    try
    {
        gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
        gl.viewportWidth = canvas.width;
        gl.viewportHeight = canvas.height;
    }
    catch(e){}

    if(!gl)
    {
        alert("Unable to initialize WebGL. Check if your browser supports it.");
    }

    return gl;
}


//Load Shader Program From Document By ID
function getShader(gl, id)
{
    var shaderScript = document.getElementById(id);

    if(!shaderScript)
    {
        alert("Shader could not be found.");
        return null;        // No element with such ID
    }

    var shaderSource = "";
    var currentChild = shaderScript.firstChild;

    while(currentChild)
    {
        if(currentChild.nodeType == 3)
        {
            shaderSource += currentChild.textContent;
        }
        currentChild = currentChild.nextSibling;
    }

    // Shader Script Type Determination By MIME Type
    var shader;

    if(shaderScript.type == "x-shader/x-fragment")
    {
        shader = gl.createShader(gl.FRAGMENT_SHADER);
    }
    else if(shaderScript.type == "x-shader/x-vertex")
    {
        shader = gl.createShader(gl.VERTEX_SHADER);
    }
    else
    {
        alert("Unknown shader type.");
        return null;        // Unknown shader type
    }

    // Send Source To Shader Object
    gl.shaderSource(shader, shaderSource);

    // Compile Shader Program
    gl.compileShader(shader);

    // Check Compilatiotion
    if(!gl.getShaderParameter(shader, gl.COMPILE_STATUS))
    {
        alert(gl.getShaderInfoLog(shader));
        return null;
    }

    return shader;
}


function initShaders()
{
    var fragmentShader = getShader(gl, "shader-fs");
    var vertexShader = getShader(gl, "shader-vs");

    // Create Shader Program
    shaderProgram = gl.createProgram();
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);
    gl.linkProgram(shaderProgram);

    // Shader Program Creation Error Report
    if(!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS))
    {
        alert("Unable to initialize shader program.");
    }

    gl.useProgram(shaderProgram);

    shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");     // Store aVertexPossition defined in shader
    gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);                                  // Turn on vertex position attribute at specified position
    shaderProgram.textureCoordAttribute = gl.getAttribLocation(shaderProgram, "aTextureCoord");         // Store aTextureCoord defined in shader
    gl.enableVertexAttribArray(shaderProgram.textureCoordAttribute);                                    // Turn on vertex texture attribute at specified position
    shaderProgram.pMatrixUniform = gl.getUniformLocation(shaderProgram, "uPMatrix");                    // Store uPMatrix defined in shader - Projection Matrix
    shaderProgram.mvMatrixUniform = gl.getUniformLocation(shaderProgram, "uMVMatrix");                  // Store uMVMatrix defined in shader - Model-View Matrix
    shaderProgram.samplerUniform = gl.getUniformLocation(shaderProgram, "uSampler");                    // Store uSampler defined in shader
}


function setMatrixUniforms()
{
    gl.uniformMatrix4fv(shaderProgram.pMatrixUniform, false, pMatrix);
    gl.uniformMatrix4fv(shaderProgram.mvMatrixUniform, false, mvMatrix);
}


function initTextures()
{
    seaTexture = gl.createTexture();
    seaTexture.image = new Image();
    seaTexture.image.onload = function()
    {
        handleTextureLoaded(seaTexture)
    };  // Async Loading
    seaTexture.image.src = "./assets/terrain/sea.png";

    skyboxTexture = gl.createTexture();
    skyboxTexture.image = new Image();
    skyboxTexture.image.onload = function()
    {
        handleTextureLoaded(skyboxTexture);
    };
    skyboxTexture.image.src = "./assets/terrain/skybox.png";

    battleshipTexture = gl.createTexture();
    battleshipTexture.image = new Image();
    battleshipTexture.image.onload = function()
    {
        handleTextureLoaded(battleshipTexture);
    };
    battleshipTexture.image.src = "./assets/models/battleshipTexture.png"; 

    bsShellTexture = gl.createTexture();
    bsShellTexture.image = new Image();
    bsShellTexture.image.onload = function()
    {
        handleTextureLoaded(bsShellTexture);
    };
    bsShellTexture.image.src = "./assets/models/shellTexture.png"; 

    enemyShipTexture = gl.createTexture();
    enemyShipTexture.image = new Image();
    enemyShipTexture.image.onload = function()
    {
        handleTextureLoaded(enemyShipTexture);
    };
    enemyShipTexture.image.src = "./assets/models/enemyShipTexture.png";
    
    enemyHitboxTexture = gl.createTexture();
    enemyHitboxTexture.image = new Image();
    enemyHitboxTexture.image.onload = function()
    {
        handleTextureLoaded(enemyHitboxTexture);
    };
    enemyHitboxTexture.image.src = "./assets/terrain/hitboxTexture.png";

    worldTexture = gl.createTexture();
    worldTexture.image = new Image();
    worldTexture.image.onload = function()
    {
        handleTextureLoaded(worldTexture);
    };
    worldTexture.image.src = "./assets/terrain/sand.jpg";

    explosionTexture = gl.createTexture();
    explosionTexture.image = new Image();
    explosionTexture.image.onload = function()
    {
        handleTextureLoaded(explosionTexture);
    };
    explosionTexture.image.src = "./assets/models/explosion.png";
}


function handleTextureLoaded(texture)
{
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);

    // Linear interpolation approximation w/ nearest Mipmap
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, texture.image);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.generateMipmap(gl.TEXTURE_2D);

    gl.bindTexture(gl.TEXTURE_2D, null);

    texturesLoaded += 1;
}


function handleLoadedSkybox(data)
{
    var lines = data.split("\n");
    var vertexCount = 0;
    var vertexPositions = [];
    var vertexTextureCoords = [];
    for(var i in lines) 
    {
        var vals = lines[i].replace(/^\s+/, "").split(/\s+/);
        if (vals.length == 5 && vals[0] != "//") 
        {
            // Lines describing vertexes;  X, Y and Z
            vertexPositions.push(parseFloat(vals[0]));
            vertexPositions.push(parseFloat(vals[1]));
            vertexPositions.push(parseFloat(vals[2]));

            // Followed by texture coordinates
            vertexTextureCoords.push(parseFloat(vals[3]));
            vertexTextureCoords.push(parseFloat(vals[4]));

            vertexCount += 1;
        }
    }
    transformScale(vertexPositions, 5);
    skyboxVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, skyboxVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexPositions), gl.STATIC_DRAW);
    skyboxVertexPositionBuffer.itemSize = 3;
    skyboxVertexPositionBuffer.numItems = vertexCount;

    skyboxVertexTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, skyboxVertexTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexTextureCoords), gl.STATIC_DRAW);
    skyboxVertexTextureCoordBuffer.itemSize = 2;
    skyboxVertexTextureCoordBuffer.numItems = vertexCount;
}


function handleLoadedSea(data)
{
    var lines = data.split("\n");
    var vertexCount = 0;
    var vertexPositions = [];
    var vertexTextureCoords = [];
    for(var i in lines) 
    {
        var vals = lines[i].replace(/^\s+/, "").split(/\s+/);
        if (vals.length == 5 && vals[0] != "//") 
        {
            // Lines describing vertexes;  X, Y and Z
            vertexPositions.push(parseFloat(vals[0]));
            vertexPositions.push(parseFloat(vals[1]));
            vertexPositions.push(parseFloat(vals[2]));

            // Followed by texture coordinates
            vertexTextureCoords.push(parseFloat(vals[3]));
            vertexTextureCoords.push(parseFloat(vals[4]));

            vertexCount += 1;
        }
    }

    seaVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, seaVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexPositions), gl.STATIC_DRAW);
    seaVertexPositionBuffer.itemSize = 3;
    seaVertexPositionBuffer.numItems = vertexCount;

    seaVertexTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, seaVertexTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexTextureCoords), gl.STATIC_DRAW);
    seaVertexTextureCoordBuffer.itemSize = 2;
    seaVertexTextureCoordBuffer.numItems = vertexCount;
}


function handleLoadedBattleship(data)
{
    battleship = JSON.parse(data);
    battleshipVertices = battleship.meshes[0].vertices;
    transformScale(battleshipVertices, 0.1);

    battleshipIndices = [].concat.apply([], battleship.meshes[0].faces);
    battleshipTexCoords = battleship.meshes[0].texturecoords[0];

    battleshipVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, battleshipVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(battleshipVertices), gl.STATIC_DRAW);
    battleshipVertexPositionBuffer.itemSize = 3;
    battleshipVertexPositionBuffer.numItems = battleshipVertices.length;

    battleshipTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, battleshipTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(battleshipTexCoords), gl.STATIC_DRAW);
    battleshipTextureCoordBuffer.itemSize = 2;
    battleshipTextureCoordBuffer.numItems = battleshipTexCoords.length;

    battleshipIndicesBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, battleshipIndicesBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(battleshipIndices), gl.STATIC_DRAW);   
    battleshipIndicesBuffer.itemSize = 1;
    battleshipIndicesBuffer.numItems = battleshipIndices.length;   
}


function handleLoadedbsShell(data)
{
    bsShell = JSON.parse(data);
    bsShellVertices = bsShell.meshes[0].vertices;
    transformScale(bsShellVertices, 0.10);

    bsShellIndices = [].concat.apply([], bsShell.meshes[0].faces);
    bsShellTexCoords = bsShell.meshes[0].texturecoords[0];

    bsShellVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, bsShellVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(bsShellVertices), gl.STATIC_DRAW);
    bsShellVertexPositionBuffer.itemSize = 3;
    bsShellVertexPositionBuffer.numItems = bsShellVertices.length;

    bsShellTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, bsShellTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(bsShellTexCoords), gl.STATIC_DRAW);
    bsShellTextureCoordBuffer.itemSize = 2;
    bsShellTextureCoordBuffer.numItems = bsShellTexCoords.length;

    bsShellIndicesBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, bsShellIndicesBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(bsShellIndices), gl.STATIC_DRAW);   
    bsShellIndicesBuffer.itemSize = 1;
    bsShellIndicesBuffer.numItems = bsShellIndices.length;   
}


function handleLoadedEnemyShip(data)
{
    enemyShip = JSON.parse(data);
    enemyShipVertices = enemyShip.meshes[0].vertices;
    transformScale(enemyShipVertices, 0.09);

    enemyShipIndices = [].concat.apply([], enemyShip.meshes[0].faces);
    enemyShipTexCoords = enemyShip.meshes[0].texturecoords[0];

    enemyShipVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, enemyShipVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(enemyShipVertices), gl.STATIC_DRAW);
    enemyShipVertexPositionBuffer.itemSize = 3;
    enemyShipVertexPositionBuffer.numItems = enemyShipVertices.length;

    enemyShipTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, enemyShipTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(enemyShipTexCoords), gl.STATIC_DRAW);
    enemyShipTextureCoordBuffer.itemSize = 2;
    enemyShipTextureCoordBuffer.numItems = enemyShipTexCoords.length;

    enemyShipIndicesBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, enemyShipIndicesBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(enemyShipIndices), gl.STATIC_DRAW);   
    enemyShipIndicesBuffer.itemSize = 1;
    enemyShipIndicesBuffer.numItems = enemyShipIndices.length;   
}


function handleLoadedenemyHitbox(data)
{
    var lines = data.split("\n");
    var vertexCount = 0;
    var vertexPositions = [];
    var vertexTextureCoords = [];
    for(var i in lines) 
    {
        var vals = lines[i].replace(/^\s+/, "").split(/\s+/);
        if (vals.length == 5 && vals[0] != "//") 
        {
            // Lines describing vertexes;  X, Y and Z
            vertexPositions.push(parseFloat(vals[0]));
            vertexPositions.push(parseFloat(vals[1]));
            vertexPositions.push(parseFloat(vals[2]));

            // Followed by texture coordinates
            vertexTextureCoords.push(parseFloat(vals[3]));
            vertexTextureCoords.push(parseFloat(vals[4]));

            vertexCount += 1;
        }
    }

    enemyShipDefaultHitbox = vertexPositions;
    enemyHitboxVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, enemyHitboxVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexPositions), gl.STATIC_DRAW);
    enemyHitboxVertexPositionBuffer.itemSize = 3;
    enemyHitboxVertexPositionBuffer.numItems = vertexCount;

    enemyHitboxVertexTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, enemyHitboxVertexTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexTextureCoords), gl.STATIC_DRAW);
    enemyHitboxVertexTextureCoordBuffer.itemSize = 2;
    enemyHitboxVertexTextureCoordBuffer.numItems = vertexCount;
}


function handleLoadedWorld(data)
{
    world = JSON.parse(data);
    worldVertices = world.meshes[0].vertices;
    transformScale(worldVertices, 500);

    worldIndices = [].concat.apply([], world.meshes[0].faces);
    worldTexCoords = world.meshes[0].texturecoords[0];

    worldVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, worldVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(worldVertices), gl.STATIC_DRAW);
    worldVertexPositionBuffer.itemSize = 3;
    worldVertexPositionBuffer.numItems = worldVertices.length;

    worldTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, worldTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(worldTexCoords), gl.STATIC_DRAW);
    worldTextureCoordBuffer.itemSize = 2;
    worldTextureCoordBuffer.numItems = worldTexCoords.length;

    worldIndicesBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, worldIndicesBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(worldIndices), gl.STATIC_DRAW);   
    worldIndicesBuffer.itemSize = 1;
    worldIndicesBuffer.numItems = worldIndices.length;   
}


function handleLoadedExplosion(data)
{
    var lines = data.split("\n");
    var vertexCount = 0;
    var vertexPositions = [];
    var vertexTextureCoords = [];
    for(var i in lines) 
    {
        var vals = lines[i].replace(/^\s+/, "").split(/\s+/);
        if (vals.length == 5 && vals[0] != "//") 
        {
            // Lines describing vertexes;  X, Y and Z
            vertexPositions.push(parseFloat(vals[0]));
            vertexPositions.push(parseFloat(vals[1]));
            vertexPositions.push(parseFloat(vals[2]));

            // Followed by texture coordinates
            vertexTextureCoords.push(parseFloat(vals[3]));
            vertexTextureCoords.push(parseFloat(vals[4]));

            vertexCount += 1;
        }
    }

    explosionVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, explosionVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexPositions), gl.STATIC_DRAW);
    explosionVertexPositionBuffer.itemSize = 3;
    explosionVertexPositionBuffer.numItems = vertexCount;

    explosionVertexTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, explosionVertexTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexTextureCoords), gl.STATIC_DRAW);
    explosionVertexTextureCoordBuffer.itemSize = 2;
    explosionVertexTextureCoordBuffer.numItems = vertexCount;
}


function loadenemyHitbox() 
{
    var request = new XMLHttpRequest();
    request.open("GET", "./assets/terrain/enemyHitbox.txt");
    request.onreadystatechange = function () 
    {
      if(request.readyState == 4) 
      {
        handleLoadedenemyHitbox(request.responseText);
      }
    }
    request.send();
}


function loadSkybox() 
{
    var request = new XMLHttpRequest();
    request.open("GET", "./assets/terrain/skybox.txt");
    request.onreadystatechange = function () 
    {
      if(request.readyState == 4) 
      {
        handleLoadedSkybox(request.responseText);
      }
    }
    request.send();
}


function loadSea()
{
    var request = new XMLHttpRequest();
    request.open("GET", "./assets/terrain/sea.txt");
    request.onreadystatechange = function () 
    {
      if(request.readyState == 4) 
      {
        handleLoadedSea(request.responseText);
      }
    }
    request.send();
}


function loadBattleship()
{
    var request = new XMLHttpRequest();
    request.open("GET", "./assets/models/battleshipModel.json");
    request.onreadystatechange = function () 
    {
      if(request.readyState == 4) 
      {
        handleLoadedBattleship(request.responseText);
      }
    }
    request.send();
}


function loadbsShell()
{
    var request = new XMLHttpRequest();
    request.open("GET", "./assets/models/shellModel.json");
    request.onreadystatechange = function () 
    {
      if(request.readyState == 4) 
      {
        handleLoadedbsShell(request.responseText);
      }
    }
    request.send();
}


function loadEnemyShip()
{
    var request = new XMLHttpRequest();
    request.open("GET", "./assets/models/enemyShipModel.json");
    request.onreadystatechange = function () 
    {
      if(request.readyState == 4) 
      {
        handleLoadedEnemyShip(request.responseText);
      }
    }
    request.send();
}


function loadWorld()
{
    var request = new XMLHttpRequest();
    request.open("GET", "./assets/terrain/world.json");
    request.onreadystatechange = function () 
    {
      if(request.readyState == 4) 
      {
        handleLoadedWorld(request.responseText);
      }
    }
    request.send();
}


function loadExplosion()
{
    var request = new XMLHttpRequest();
    request.open("GET", "./assets/models/explosion.txt");
    request.onreadystatechange = function () 
    {
      if(request.readyState == 4) 
      {
        handleLoadedExplosion(request.responseText);
      }
    }
    request.send();
}


function objectDraw(texture, vPB, vTCB)
{
    try
    {
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.uniform1i(shaderProgram.samplerUniform, 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, vTCB);
        gl.vertexAttribPointer(shaderProgram.textureCoordAttribute, vTCB.itemSize, gl.FLOAT, false, 0, 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, vPB);
        gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, vPB.itemSize, gl.FLOAT, false, 0, 0);

        setMatrixUniforms();
        gl.drawArrays(gl.TRIANGLES, 0, vPB.numItems);
    }
    catch(e){}
}


function modelDraw(texture, vPB, vTCB, vIB)
{
    try
    {
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.uniform1i(shaderProgram.samplerUniform, 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, vPB);
        gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, vPB.itemSize, gl.FLOAT, false, 0, 0);
        
        gl.bindBuffer(gl.ARRAY_BUFFER, vTCB);
        gl.vertexAttribPointer(shaderProgram.textureCoordAttribute, vTCB.itemSize, gl.FLOAT, false, 0, 0);
    
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, vIB);
        setMatrixUniforms();
        gl.drawElements(gl.TRIANGLES, vIB.numItems, gl.UNSIGNED_SHORT, 0);
    }
    catch(e){}
}


function shootMainGun()
{
    var timeMainGun = new Date().getTime();
    var gunElapsed = timeMainGun - lastShot;

    if((gunElapsed >= mainReload && nextGun == 1) || (gunElapsed >= mainDelay && nextGun == 2) || lastShot == 0)
    {
        if(nextGun == 1)
        {
            shellsFired.push([-cameraX - 0.14 +xPosition, -cameraY + 0.45, -cameraZ - 2.5 + zPosition, -yaw, timeMainGun, 0, false]);
            lastShot = timeMainGun;
        }
        else
        {
            shellsFired.push([-cameraX - 0.14 + 0.284 +xPosition, -cameraY + 0.45, -cameraZ - 2.5 +zPosition, -yaw, timeMainGun, 0, false]);
            lastSHot = timeMainGun;
        }
        
        if(nextGun == 1)
        {
            nextGun = 2;
        }
        else
        {
            nextGun = 1;
        }
    }
}


function removeShells()
{
    try
    {
        while(shellsFired[0][5] >= bsShellMaxDistance || shellsFired[0][6] == true)
        {
            shellsFired = shellsFired.splice(1, shellsFired.length);
        }
    }
    catch(e){}
}

function removeEnemy()
{
    var newShipList = [];

    for(var i = spawnedEnemyShips.length - 1; i > -1; i--)
    {
        if(spawnedEnemyShips[i][4] > 0)
        {
            newShipList.push(spawnedEnemyShips[i]);
        }
    }
    spawnedEnemyShips = newShipList;
}


function spawnEnenemy(x, z)
{
    var newEnemy = [x, -1.1, z, Math.random() * 360, enemyShipHealth];
    spawnedEnemyShips.push(newEnemy);
}


function checkHit()
{
    for(var i = 0; i < shellsFired.length; i++)
    {
        var deltaTime = new Date().getTime();
        
        deltaTime = deltaTime - shellsFired[i][4];

        if(Math.abs(yaw) >= 180)
        {
            var rotBuff = cameraZ;
        }
        else
        {
            var rotBuff = enemyShipDefaultHitbox[8]/2 + cameraZ;
        }

        var transformedShell = [-Math.sin(degToRad(shellsFired[i][3])) * (-deltaTime * shellSpeed) + shellsFired[i][0], Math.cos(degToRad(shellsFired[i][3])) * (-deltaTime * shellSpeed) + shellsFired[i][2] + rotBuff];
        for(var j = 0; j < spawnedEnemyShips.length; j++)
        {
            if((spawnedEnemyShips[j][0] - enemyShipDefaultHitbox[0]) < (transformedShell[0] + cameraX) && (spawnedEnemyShips[j][0] + enemyShipDefaultHitbox[0]) > (transformedShell[0] + cameraX))
            {
                if((spawnedEnemyShips[j][2] - enemyShipDefaultHitbox[8]) < (transformedShell[1] + cameraZ) && (spawnedEnemyShips[j][2] + enemyShipDefaultHitbox[8]) > (transformedShell[1] + cameraZ))
                {
                    if(shellsFired[i][6] == false)
                    { 
                        console.warn("hit");
                        spawnedEnemyShips[j][4] -= 50;
                        shellsFired[i][6] = true;
                    }
                }
            }
        }
    }
}


function setBattleShipTilt()
{
    if(battleshipTiltDirection == 0)
    {
        if(battleshipCurrentTilt < battleshipCurrentTiltMax)
        {
            battleshipCurrentTilt += battleshipTiltStep;
        }
        else
        {
            battleshipTiltDirection = 1;
            battleshipCurrentTiltMax = -(battleshipCurrentTiltMax * Math.random() + 5);
            battleshipCurrentTilt -= battleshipTiltStep;
        }
    }
    else
    {
        if(battleshipCurrentTilt > battleshipCurrentTiltMax)
        {
            battleshipCurrentTilt -= battleshipTiltStep;
        }
        else
        {
            battleshipTiltDirection = 0;
            battleshipCurrentTiltMax = battleshipCurrentTiltMax * Math.random() + 5;
            battleshipCurrentTilt += battleshipTiltStep;
        }
    }
    mat4.rotate(mvMatrix, degToRad(battleshipCurrentTilt), [0, 1, 0]);
}


function drawScene()
{
    // Set Render Environment To Full Canvas Size
    gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);

    // Clear Canvas
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    mat4.perspective(45, gl.viewportWidth / gl.viewportHeight, 0.1, renderDistance, pMatrix);        // Set field of view to 45° with W/H ratio & draw distance to values between 0.1 and 100 units

    mat4.identity(mvMatrix);        // Set drawing position to "identity" point - Center of scene

    // Positioning
    mat4.rotate(mvMatrix, degToRad(-pitch), [1, 0, 0]);
    mat4.rotate(mvMatrix, degToRad(-yaw), [0, 1, 0]);
    mat4.translate(mvMatrix, [-xPosition -cameraX, -yPosition -cameraY, -zPosition -cameraZ]);
    objectDraw(seaTexture, seaVertexPositionBuffer, seaVertexTextureCoordBuffer);

    for(var s = 0; s < spawnedEnemyShips.length; s++)
    {
        mat4.identity(mvMatrix);   
        mat4.rotate(mvMatrix, degToRad(-pitch), [1, 0, 0]);
        mat4.rotate(mvMatrix, degToRad(-yaw), [0, 1, 0]);
        mat4.translate(mvMatrix, [-xPosition -cameraX +spawnedEnemyShips[s][0], -yPosition -cameraY +spawnedEnemyShips[s][1], -zPosition -cameraZ +spawnedEnemyShips[s][2]]);
        mat4.rotate(mvMatrix, degToRad(-90), [1, 0, 0]);
        mat4.rotate(mvMatrix, degToRad(-spawnedEnemyShips[s][3]), [0, 0, 1]);
        modelDraw(enemyShipTexture, enemyShipVertexPositionBuffer, enemyShipTextureCoordBuffer, enemyShipIndicesBuffer);
        
        // Uncomment to show hitboxes for enemies
        // mat4.rotate(mvMatrix, degToRad(+90), [1, 0, 0]);
        // objectDraw(enemyHitboxTexture, enemyHitboxVertexPositionBuffer, enemyHitboxVertexTextureCoordBuffer);
    }

    mat4.identity(mvMatrix);
    mat4.rotate(mvMatrix, degToRad(-pitch), [1, 0, 0]);
    mat4.translate(mvMatrix, [-cameraX, -cameraY - 1.6, -cameraZ]);
    mat4.rotate(mvMatrix, degToRad(-90), [1, 0, 0]);
    mat4.rotate(mvMatrix, degToRad(180), [0, 0, 1]); 
    setBattleShipTilt();
    modelDraw(battleshipTexture, battleshipVertexPositionBuffer, battleshipTextureCoordBuffer, battleshipIndicesBuffer);

    for(var i = 0; i < shellsFired.length; i++)
    {
        var deltaTime = new Date().getTime();
        deltaTime = deltaTime - shellsFired[i][4];
        mat4.identity(mvMatrix);
        mat4.rotate(mvMatrix, degToRad(-pitch), [1, 0, 0]);
        mat4.rotate(mvMatrix, degToRad(-yaw), [0, 1, 0]);
        mat4.rotate(mvMatrix, degToRad(-shellsFired[i][3]), [0, 1, 0]);
        mat4.translate(mvMatrix, [shellsFired[i][0] - xPosition, shellsFired[i][1] -yPosition, shellsFired[i][2] -deltaTime * shellSpeed - zPosition]);
        shellsFired[i][5] = deltaTime * shellSpeed;
        mat4.rotate(mvMatrix, degToRad(-90), [1, 0, 0]);       
        modelDraw(bsShellTexture, bsShellVertexPositionBuffer, bsShellTextureCoordBuffer, bsShellIndicesBuffer);
    }
    
    mat4.identity(mvMatrix);
    mat4.rotate(mvMatrix, degToRad(-pitch), [1, 0, 0]);
    mat4.rotate(mvMatrix, degToRad(-yaw), [0, 1, 0]);
    mat4.translate(mvMatrix, [-xPosition * skyboxDistance, 0, -zPosition * skyboxDistance]);
    objectDraw(skyboxTexture, skyboxVertexPositionBuffer, skyboxVertexTextureCoordBuffer);  

    mat4.rotate(mvMatrix, degToRad(-90), [1, 0, 0]);
    mat4.translate(mvMatrix, [-cameraX, -cameraY, -cameraZ]);
    modelDraw(worldTexture, worldVertexPositionBuffer, worldTextureCoordBuffer, worldIndicesBuffer);
}


function animate()
{
    var timeNow = new Date().getTime();
    if(lastTime != 0)
    {
        var elapsed = timeNow - lastTime;

        if (speed != 0) 
        {
            xPosition -= Math.sin(degToRad(yaw)) * speed * elapsed;
            zPosition -= Math.cos(degToRad(yaw)) * speed * elapsed;
        }
      
        yaw += yawRate * elapsed;
        if(Math.abs(yaw) >= 360)
        {
            yaw = 0;
        }

        if(pitchRate > 0 && pitch < 15 || pitchRate < 0 && pitch > -15)
        {
            pitch += pitchRate * elapsed;
        }

        if(cameraHorizontalRate < 0 && cameraX < 5 || cameraHorizontalRate > 0 && cameraX > -2.5)
        {
            cameraX -= cameraHorizontalRate * elapsed;
        }
        if(cameraVerticalRate > 0 && cameraY < 9.5 || cameraVerticalRate < 0 && cameraY > -0.3)
        {
            cameraY += cameraVerticalRate * elapsed;
        }
      
    }
    lastTime = timeNow;
}


// Keyboard Handlers
function handleKeyDown(event)
{
    currentlyPressedKeys[event.keyCode] = true;
}


function handleKeyUp(event)
{
    currentlyPressedKeys[event.keyCode] = false;
}


function handleKeys()
{
    if(currentlyPressedKeys[33])
    {
        // Page Up
        pitchRate = 0.1;

    }
    else if(currentlyPressedKeys[34])
    {
        // Page Down
        pitchRate = -0.1;
    }
    else
    {
        pitchRate = 0;
    }

    if(currentlyPressedKeys[37] || currentlyPressedKeys[65])
    {
        // Left Cursor or A
        yawRate = 0.01;
    }
    else if(currentlyPressedKeys[39] ||currentlyPressedKeys[68])
    {
        // Right Cursor or D
        yawRate = -0.01;
    }
    else
    {
        yawRate = 0;
    }

    if(currentlyPressedKeys[38] || currentlyPressedKeys[87])
    {
        // Up Cursor or W
        speed = 0.003 * multiplier;
    }
    else if(currentlyPressedKeys[40] || currentlyPressedKeys[83])
    {
        // Down Cursor or S
        speed = -0.003 * multiplier;
    }
    else
    {
        speed = 0;
    }

    if(currentlyPressedKeys[16])
    {
        // Shift
        multiplier = 2.5;
    }
    else
    {
        multiplier = 1;
    }

    if(currentlyPressedKeys[104])
    {
        // Camera Up - Numpad 8
        cameraVerticalRate = 0.001;
    }
    else if(currentlyPressedKeys[98])
    {
        // Camera Down - Numpad 2
        cameraVerticalRate = -0.001;
    }
    else
    {
        cameraVerticalRate = 0;
    }

    if(currentlyPressedKeys[100])
    {
        // Camera Left - Numpad 4
        cameraHorizontalRate = 0.001;
    }
    else if(currentlyPressedKeys[102])
    {
        // Camera Right - Numpad 6
        cameraHorizontalRate = -0.001;
    }
    else
    {
        cameraHorizontalRate = 0;
    }

    if(currentlyPressedKeys[32])
    {
        // Space - Shoot Main
        shootMain = true;
    }
    else
    {
        shootMain = false;
    }
}

// Called on load
function start() 
{
    canvas = document.getElementById("glcanvas");

    // GL Context Initialization
    gl = initGL(canvas);

    if(gl)
    {
        gl.clearColor(0.0, 0.0, 0.0, 1.0);      // Color = Black, Transparency = 0%
        gl.clearDepth(1.0);                     // Clear
        gl.enable(gl.DEPTH_TEST);               // Enable depth testing
        gl.depthFunc(gl.LEQUAL);                // Close objects drawn over far ones

        // Shader Inizialization
        initShaders();

        // Initilaize Textures
        initTextures();

        // Load Resources
        loadSkybox();
        loadWorld();
        loadSea();
        loadBattleship();
        loadbsShell();
        loadExplosion();
        loadenemyHitbox();
        loadEnemyShip();

        // Spawn Enemies
        for(var i = 0; i < 10; i++)
        {
            if(i % 4 == 0)
            {
                spawnEnenemy(Math.random() * 250 + 20, Math.random() * 250 + 20); 
            }
            else if(i % 4 == 1)
            {
                spawnEnenemy(-Math.random() * 250 + 20, Math.random() * 250 + 20);
            }
            else if(i % 4 == 2)
            {
                spawnEnenemy(Math.random() * 250 + 20, -Math.random() * 250 + 20);
            }
            else
            {
                spawnEnenemy(-Math.random() * 250 + 20, -Math.random() * 250 + 20);
            }
        }
        
        // Bind Keyboard Handlers To Document Handler
        document.onkeydown = handleKeyDown;
        document.onkeyup = handleKeyUp;

        // Refresh Rate - ms
        setInterval(function()
        {
            if(texturesLoaded >= 6)
            {
                requestAnimationFrame(animate);
                handleKeys();

                if(shootMain)
                {
                    shootMainGun();
                }
                
                removeShells();
                removeEnemy();
                drawScene();
                checkHit();
            }
        }, 1);
    }
}
