// Global Variables
var canvas;
var gl;
var shaderProgram;

// Buffers
var skyboxVertexPositionBuffer = null;
var skyboxVertexTextureCoordBuffer = null;
var seaVertexPositionBuffer = null;
var seaVertexTextureCoordBuffer = null;
var battleshipVertexPositionBuffer = null;
var battleshipIndicesBuffer = null;
var battleshipTextureCoordBuffer = null;

// Model-View &+ Matrix stack and Projection Matrices
var mvMatrixStack = [];
var mvMatrix = mat4.create();
var pMatrix = mat4.create();

// Models
var battleship;
var battleshipVertices;
var battleshipIndices;
var battleshipTexCoords;
var battleshipPositionAttribLocation;
var battleshipTexCoordAttribLocation;

// Texture Storage
var seaTexture;
var skyboxTexture;
var battleshipTexture;

// Texture Loading State
var texturesLoaded = 0;

// Controls
var currentlyPressedKeys = {};

// Camera
var cameraX = 3;
var cameraY = 2;
var cameraZ = 12;

var cameraHorizontalRate = 0;
var cameraVerticalRate = 0;

// Possition & Speed
var pitch = 0;
var pitchRate = 0;
var yaw = 0;
var yawRate = 0;
var xPosition = 0;
var yPosition = 0.4;
var zPosition = 0;
var speed = 0;
var multiplier = 1;

// Time
var lastTime = 0;


// Utility Functions
function mvPushMatrix()
{
    var copy = mat4.create();
    mat4.set(mvMatrix, copy);
    mvMatrixStack.push(copy);
}


function mvPopMatrix()
{
    if(mvMatrixStack.length == 0)
    {
        throw "Invalid popMatrix!";
    }
    mvMatrix = mvMatrixStack.pop();
}


function degToRad(degrees)
{
    return degrees * Math.PI / 180;
}


function transformScale(array, sizeMultiplier)
{
    for(var i = 0; i < array.length; i++)
    {
        array[i] = array[i] * sizeMultiplier;
    }
}

// Game Functions
function initGL(canvas)
{
    var gl = null;

    try
    {
        gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
        gl.viewportWidth = canvas.width;
        gl.viewportHeight = canvas.height;
    }
    catch(e){}

    if(!gl)
    {
        alert("Unable to initialize WebGL. Check if your browser supports it.");
    }

    return gl;
}


//Load Shader Program From Document By ID
function getShader(gl, id)
{
    var shaderScript = document.getElementById(id);

    if(!shaderScript)
    {
        alert("Shader could not be found.");
        return null;        // No element with such ID
    }

    var shaderSource = "";
    var currentChild = shaderScript.firstChild;

    while(currentChild)
    {
        if(currentChild.nodeType == 3)
        {
            shaderSource += currentChild.textContent;
        }
        currentChild = currentChild.nextSibling;
    }

    // Shader Script Type Determination By MIME Type
    var shader;

    if(shaderScript.type == "x-shader/x-fragment")
    {
        shader = gl.createShader(gl.FRAGMENT_SHADER);
    }
    else if(shaderScript.type == "x-shader/x-vertex")
    {
        shader = gl.createShader(gl.VERTEX_SHADER);
    }
    else
    {
        alert("Unknown shader type.");
        return null;        // Unknown shader type
    }

    // Send Source To Shader Object
    gl.shaderSource(shader, shaderSource);

    // Compile Shader Program
    gl.compileShader(shader);

    // Check Compilatiotion
    if(!gl.getShaderParameter(shader, gl.COMPILE_STATUS))
    {
        alert(gl.getShaderInfoLog(shader));
        return null;
    }

    return shader;
}


function initShaders()
{
    var fragmentShader = getShader(gl, "shader-fs");
    var vertexShader = getShader(gl, "shader-vs");

    // Create Shader Program
    shaderProgram = gl.createProgram();
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);
    gl.linkProgram(shaderProgram);

    // Shader Program Creation Error Report
    if(!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS))
    {
        alert("Unable to initialize shader program.");
    }

    gl.useProgram(shaderProgram);

    shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");     // Store aVertexPossition defined in shader
    gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);                                  // Turn on vertex position attribute at specified position
    shaderProgram.textureCoordAttribute = gl.getAttribLocation(shaderProgram, "aTextureCoord");         // Store aTextureCoord defined in shader
    gl.enableVertexAttribArray(shaderProgram.textureCoordAttribute);                                    // Turn on vertex texture attribute at specified position
    shaderProgram.pMatrixUniform = gl.getUniformLocation(shaderProgram, "uPMatrix");                    // Store uPMatrix defined in shader - Projection Matrix
    shaderProgram.mvMatrixUniform = gl.getUniformLocation(shaderProgram, "uMVMatrix");                  // Store uMVMatrix defined in shader - Model-View Matrix
    shaderProgram.samplerUniform = gl.getUniformLocation(shaderProgram, "uSampler");                    // Store uSampler defined in shader
}


function setMatrixUniforms()
{
    gl.uniformMatrix4fv(shaderProgram.pMatrixUniform, false, pMatrix);
    gl.uniformMatrix4fv(shaderProgram.mvMatrixUniform, false, mvMatrix);
}


function initTextures()
{
    seaTexture = gl.createTexture();
    seaTexture.image = new Image();
    seaTexture.image.onload = function()
    {
        handleTextureLoaded(seaTexture)
    };  // Async Loading
    seaTexture.image.src = "./assets/terrain/sea.png";

    skyboxTexture = gl.createTexture();
    skyboxTexture.image = new Image();
    skyboxTexture.image.onload = function()
    {
        handleTextureLoaded(skyboxTexture);
    };
    skyboxTexture.image.src = "./assets/terrain/skybox.png";

    battleshipTexture = gl.createTexture();
    battleshipTexture.image = new Image();
    battleshipTexture.image.onload = function()
    {
        handleTextureLoaded(battleshipTexture);
    };
    battleshipTexture.image.src = "./assets/models/battleshipTexture.png"; 
}


function handleTextureLoaded(texture)
{
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);

    // Linear interpolation approximation w/ nearest Mipmap
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, texture.image);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.generateMipmap(gl.TEXTURE_2D);

    gl.bindTexture(gl.TEXTURE_2D, null);

    texturesLoaded += 1;
}


function handleLoadedSkybox(data)
{
    var lines = data.split("\n");
    var vertexCount = 0;
    var vertexPositions = [];
    var vertexTextureCoords = [];
    for(var i in lines) 
    {
        var vals = lines[i].replace(/^\s+/, "").split(/\s+/);
        if (vals.length == 5 && vals[0] != "//") 
        {
            // Lines describing vertexes;  X, Y and Z
            vertexPositions.push(parseFloat(vals[0]));
            vertexPositions.push(parseFloat(vals[1]));
            vertexPositions.push(parseFloat(vals[2]));

            // Followed by texture coordinates
            vertexTextureCoords.push(parseFloat(vals[3]));
            vertexTextureCoords.push(parseFloat(vals[4]));

            vertexCount += 1;
        }
    }

    skyboxVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, skyboxVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexPositions), gl.STATIC_DRAW);
    skyboxVertexPositionBuffer.itemSize = 3;
    skyboxVertexPositionBuffer.numItems = vertexCount;

    skyboxVertexTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, skyboxVertexTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexTextureCoords), gl.STATIC_DRAW);
    skyboxVertexTextureCoordBuffer.itemSize = 2;
    skyboxVertexTextureCoordBuffer.numItems = vertexCount;
}


function handleLoadedSea(data)
{
    var lines = data.split("\n");
    var vertexCount = 0;
    var vertexPositions = [];
    var vertexTextureCoords = [];
    for(var i in lines) 
    {
        var vals = lines[i].replace(/^\s+/, "").split(/\s+/);
        if (vals.length == 5 && vals[0] != "//") 
        {
            // Lines describing vertexes;  X, Y and Z
            vertexPositions.push(parseFloat(vals[0]));
            vertexPositions.push(parseFloat(vals[1]));
            vertexPositions.push(parseFloat(vals[2]));

            // Followed by texture coordinates
            vertexTextureCoords.push(parseFloat(vals[3]));
            vertexTextureCoords.push(parseFloat(vals[4]));

            vertexCount += 1;
        }
    }

    seaVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, seaVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexPositions), gl.STATIC_DRAW);
    seaVertexPositionBuffer.itemSize = 3;
    seaVertexPositionBuffer.numItems = vertexCount;

    seaVertexTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, seaVertexTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexTextureCoords), gl.STATIC_DRAW);
    seaVertexTextureCoordBuffer.itemSize = 2;
    seaVertexTextureCoordBuffer.numItems = vertexCount;
}


function loadSkybox() 
{
    var request = new XMLHttpRequest();
    request.open("GET", "./assets/terrain/skybox.txt");
    request.onreadystatechange = function () 
    {
      if(request.readyState == 4) 
      {
        handleLoadedSkybox(request.responseText);
      }
    }
    request.send();
}


function handleLoadedBattleship(data)
{
    battleship = JSON.parse(data);
    battleshipVertices = battleship.meshes[0].vertices;
    transformScale(battleshipVertices, 0.1);

    battleshipIndices = [].concat.apply([], battleship.meshes[0].faces);
    battleshipTexCoords = battleship.meshes[0].texturecoords[0];

    battleshipVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, battleshipVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(battleshipVertices), gl.STATIC_DRAW);
    battleshipVertexPositionBuffer.itemSize = 3;
    battleshipVertexPositionBuffer.numItems = battleshipVertices.length;

    battleshipTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, battleshipTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(battleshipTexCoords), gl.STATIC_DRAW);
    battleshipTextureCoordBuffer.itemSize = 2;
    battleshipTextureCoordBuffer.numItems = battleshipTexCoords.length;

    battleshipIndicesBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, battleshipIndicesBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(battleshipIndices), gl.STATIC_DRAW);   
    battleshipIndicesBuffer.itemSize = 1;
    battleshipIndicesBuffer.numItems = battleshipIndices.length;   
}


function loadSea()
{
    var request = new XMLHttpRequest();
    request.open("GET", "./assets/terrain/sea.txt");
    request.onreadystatechange = function () 
    {
      if(request.readyState == 4) 
      {
        handleLoadedSea(request.responseText);
      }
    }
    request.send();
}

function loadBattleship()
{
    var request = new XMLHttpRequest();
    request.open("GET", "./assets/models/battleshipModel.json");
    request.onreadystatechange = function () 
    {
      if(request.readyState == 4) 
      {
        handleLoadedBattleship(request.responseText);
      }
    }
    request.send();
}


function objectDraw(texture, vPB, vTCB)
{
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.uniform1i(shaderProgram.samplerUniform, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, vTCB);
    gl.vertexAttribPointer(shaderProgram.textureCoordAttribute, vTCB.itemSize, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, vPB);
    gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, vPB.itemSize, gl.FLOAT, false, 0, 0);

    setMatrixUniforms();
    gl.drawArrays(gl.TRIANGLES, 0, vPB.numItems);
}


function modelDraw(texture, vPB, vTCB, vIB)
{
    try
    {
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.uniform1i(shaderProgram.samplerUniform, 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, vPB);
        gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, vPB.itemSize, gl.FLOAT, false, 0, 0);
        
        gl.bindBuffer(gl.ARRAY_BUFFER, vTCB);
        gl.vertexAttribPointer(shaderProgram.textureCoordAttribute, vTCB.itemSize, gl.FLOAT, false, 0, 0);
    
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, vIB);
        setMatrixUniforms();
        gl.drawElements(gl.TRIANGLES, vIB.numItems, gl.UNSIGNED_SHORT, 0);
    }
    catch(e){}
}


function drawScene()
{
    // Set Render Environment To Full Canvas Size
    gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);

    // Clear Canvas
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    if(skyboxVertexTextureCoordBuffer == null || skyboxVertexPositionBuffer == null || seaVertexPositionBuffer == null || seaVertexTextureCoordBuffer == null) 
    {
        alert("Buffer empty - Application will not load.");
        return;
    }

    mat4.perspective(45, gl.viewportWidth / gl.viewportHeight, 0.1, 300.0, pMatrix);        // Set field of view to 45° with W/H ratio & draw distance to values between 0.1 and 100 units

    mat4.identity(mvMatrix);        // Set drawing position to "identity" point - Center of scene

    // Poswwitioning
    mat4.rotate(mvMatrix, degToRad(-pitch), [1, 0, 0]);
    mat4.translate(mvMatrix, [-cameraX, -cameraY - 1.5, -cameraZ]);
    mat4.rotate(mvMatrix, degToRad(-90), [1, 0, 0]);
    mat4.rotate(mvMatrix, degToRad(180), [0, 0, 1]); 
    modelDraw(battleshipTexture, battleshipVertexPositionBuffer, battleshipTextureCoordBuffer, battleshipIndicesBuffer);

    mat4.identity(mvMatrix);
    mat4.rotate(mvMatrix, degToRad(-pitch), [1, 0, 0]);
    mat4.rotate(mvMatrix, degToRad(-yaw), [0, 1, 0]);
    objectDraw(skyboxTexture, skyboxVertexPositionBuffer, skyboxVertexTextureCoordBuffer);

    mat4.identity(mvMatrix);
    mat4.rotate(mvMatrix, degToRad(-pitch), [1, 0, 0]);
    mat4.rotate(mvMatrix, degToRad(-yaw), [0, 1, 0]);
    mat4.translate(mvMatrix, [-xPosition - cameraX, -yPosition - cameraY, -zPosition - cameraZ]);
    
    objectDraw(seaTexture, seaVertexPositionBuffer, seaVertexTextureCoordBuffer);
}


function animate()
{
    var timeNow = new Date().getTime();
    if(lastTime != 0)
    {
        var elapsed = timeNow - lastTime;

        if (speed != 0) 
        {
            xPosition -= Math.sin(degToRad(yaw)) * speed * elapsed;
            zPosition -= Math.cos(degToRad(yaw)) * speed * elapsed;
        }
      
        yaw += yawRate * elapsed;
        if(pitchRate > 0 && pitch < 15 || pitchRate < 0 && pitch > -15)
        {
            pitch += pitchRate * elapsed;
        }

        if(cameraHorizontalRate < 0 && cameraX < 5 || cameraHorizontalRate > 0 && cameraX > -2.5)
        {
            cameraX -= cameraHorizontalRate * elapsed;
        }
        if(cameraVerticalRate > 0 && cameraY < 9.5 || cameraVerticalRate < 0 && cameraY > -0.3)
        {
            cameraY += cameraVerticalRate * elapsed;
        }
      
    }
    lastTime = timeNow;
}


// Keyboard Handlers
function handleKeyDown(event)
{
    currentlyPressedKeys[event.keyCode] = true;
}


function handleKeyUp(event)
{
    currentlyPressedKeys[event.keyCode] = false;
}


function handleKeys()
{
    if(currentlyPressedKeys[33])
    {
        // Page Up
        pitchRate = 0.1;

    }
    else if(currentlyPressedKeys[34])
    {
        // Page Down
        pitchRate = -0.1;
    }
    else
    {
        pitchRate = 0;
    }

    if(currentlyPressedKeys[37] || currentlyPressedKeys[65])
    {
        // Left Cursor or A
        yawRate = 0.01;
    }
    else if(currentlyPressedKeys[39] ||currentlyPressedKeys[68])
    {
        // Right Cursor or D
        yawRate = -0.01;
    }
    else
    {
        yawRate = 0;
    }

    if(currentlyPressedKeys[38] || currentlyPressedKeys[87])
    {
        // Up Cursor or W
        speed = 0.003 * multiplier;
    }
    else if(currentlyPressedKeys[40] || currentlyPressedKeys[83])
    {
        // Down Cursor or S
        speed = -0.003 * multiplier;
    }
    else
    {
        speed = 0;
    }

    if(currentlyPressedKeys[16])
    {
        // Shift
        multiplier = 2.5;
    }
    else
    {
        multiplier = 1;
    }

    if(currentlyPressedKeys[104])
    {
        // Camera Up - Numpad 8
        cameraVerticalRate = 0.001;
    }
    else if(currentlyPressedKeys[98])
    {
        // Camera Down - Numpad 2
        cameraVerticalRate = -0.001;
    }
    else
    {
        cameraVerticalRate = 0;
    }

    if(currentlyPressedKeys[100])
    {
        // Camera Left - Numpad 4
        cameraHorizontalRate = 0.001;
    }
    else if(currentlyPressedKeys[102])
    {
        // Camera Right - Numpad 6
        cameraHorizontalRate = -0.001;
    }
    else
    {
        cameraHorizontalRate = 0;
    }
}

// Called on load
function start() 
{
    canvas = document.getElementById("glcanvas");

    // GL Context Initialization
    gl = initGL(canvas);

    if(gl)
    {
        gl.clearColor(0.0, 0.0, 0.0, 1.0);                      // Color = Black, Transparency = 0%
        gl.clearDepth(1.0);                                     // Clear
        gl.enable(gl.DEPTH_TEST);                               // Enable depth testing
        gl.depthFunc(gl.LEQUAL);                                // Close objects drawn over far ones

        // Shader Inizialization
        initShaders();

        // Initilaize Textures
        initTextures();

        // Load Skybox
        loadSkybox();

        // Load Sea
        loadSea();

        // Load Battleship
        loadBattleship();

        // Bind Keyboard Handlers To Document Handler
        document.onkeydown = handleKeyDown;
        document.onkeyup = handleKeyUp;

        // Refresh Rate - ms
        setInterval(function()
        {
            if(texturesLoaded >= 3)
            {
                requestAnimationFrame(animate);
                handleKeys();
                drawScene();
            }
        }, 1);
    }
}
